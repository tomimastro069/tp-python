public class Main {
    public static void main(String[] args) {
        Cajero_Automatico c1 = new Cajero_Automatico();

    }
}